﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace RelSc
{
    public partial class Form1 : Form
    {
        

        List<List<int>> AllScema_Way = new List<List<int>>();

        

        List<ScemaElement> ScElem = new List<ScemaElement>();

        Random rnd = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        


        //изменить вероятность у элемента по названию
        //на ввод номер(название) элемента и вероятность в диапозоне 0<=x=>1
        /*private void UpdateVer(int num, double ver)
        { //Проход по листу листов
            foreach (var item in AllScema)
            {
                foreach (var item1 in item)
                {
                    if (item1.Num == num)
                    {
                        item1.Ver = ver;
                    }
                }

            }
        }
        */

        //Кнопка Рассчётов

        private void button3_Click(object sender, EventArgs e)
        {
            //Считаем Вероятность
            double chway = 1;
            double chastota = 0;

            //int TableTrue[32][5];
            int n = ScElem.Count; // Количество переменных
            List<List<int>> truthTable = new List<List<int>>();
            for (int i = 0; i < (1 << n); i++)
            {
                List<int> row = new List<int>();
                for (int j = 0; j < n; j++)
                {
                    if ((i & (1 << j)) != 0)
                    {
                        row.Add(1);
                    }
                    else
                    {
                        row.Add(0);
                    }
                }
                truthTable.Add(row);
            }


            List<List<int>> AllScemaShort = new List<List<int>>();
            foreach (var item in AllScema_Way)
            {
                List<int> row = new List<int>();

                foreach (var item1 in ScElem)
                {
                    
                    if (item.Exists(i => i == item1.Num))
                    {
                        row.Add(1);
                    }
                    else
                    {
                        row.Add(0);
                    }
                    


                    }
                AllScemaShort.Add(row);
            }

            List<List<int>> AllScemaExt = new List<List<int>>();
            //bool good = false;
            foreach (var itemS in AllScemaShort)
            {
                //foreach(var itemT in truthTable)

                for(int j = 0; j< truthTable.Count;j++)
                {
                    var itemT = truthTable[j];
                    for (int i = 0; i < ScElem.Count; i++)
                    {
                        if (itemS[i] == 1 && itemT[i]==0)
                        {
                            break;
                        }
                        if(i==ScElem.Count-1)
                        {
                            /*List<int> row = new List<int>();
                            row = itemT;*/
                            AllScemaExt.Add(itemT);
                            truthTable.Remove(itemT);
                            j--;
                        }
                    }
                }

            }



            foreach (var item in AllScemaExt)
            {
                for (int i = 0; i < ScElem.Count; i++)
                {
                    if (item[i] == 1)
                    {
                        chway *= ScElem[i].Ver;
                    }
                    else
                    {
                        chway *= (1 - ScElem[i].Ver);
                    }
                }


                /*if(ScElem.Exists(item2 =>item2.Num==item1))
                {
                    ScemaElement tmp = new ScemaElement();
                    tmp = ScElem.Find(i=>i.Num==item1);
                    chway *= tmp.Ver;
                }*/
                chastota += chway;
                chway = 1;

            }
                
            
            
            label1.Text = chastota.ToString();

            //Частота

            int Count = Convert.ToInt32(textBox6.Text); //Число испытаний
            int Count_SC = 0;
            bool Way_open = false;

            for (int i = 0; i <= Count; i++)
            {
                ScElem.ForEach(item => item.Run_Element()); //

                foreach (var item in AllScema_Way)
                {
                    foreach (var item1 in item)
                    {

                        ScemaElement tmp = ScElem.Find(it => it.Num == item1);

                        if (tmp.IsActive)
                        {
                            Way_open = true;
                        }
                        else
                        {
                            Way_open = false;
                            break;
                        }

                    }

                    if (Way_open)
                    {
                        Count_SC++;
                        Way_open = false;   //возможно излишне
                        break;
                    }

                }
            }
            double tmpout = (double)Count_SC / (double)Count;
            label2.Text = tmpout.ToString();

        }


        private void Update_Count_Button()
        {
            try
            {
                Scema_Way TMPscema_Way = new Scema_Way(AllScema_Way, ScElem);
                button1.Enabled = true;
            }
            catch (Exception ex) { button1.Enabled = false; }
        }

        private void Save_Ways ()
        {
            AllScema_Way.Clear();
            foreach (var item in listBox2.Items)
            {
                
                string[] ScWay = item.ToString().Split(' ');

                List<int> Way = new List<int>();

                for (int i = 0; i < ScWay.Length; i++)
                {
                    if (ScWay[i]!="")
                    Way.Add(Convert.ToInt32(ScWay[i]));
                }
                //Добавить путь в схему путей
                AllScema_Way.Add(Way);

                if (AllScema_Way.Count == 0 || ScElem.Count == 0)
                {
                    button1.Enabled = false;
                }
                else { button1.Enabled = true; }
            }
        }

        //Добавить Элемент из интерфейса
        
        //todo
        private void button4_Click(object sender, EventArgs e)
        {
            //todo проверки
            try
            {
                int Num = Convert.ToInt32(textBox3.Text);
                double Ver = Convert.ToDouble(textBox4.Text);

                //Если элемента с таким именем нет
                if (!ScElem.Any(item => item.Num == Num))
                {
                    //Создаём элемент
                    //todo - конструктор
                    ScemaElement tmp = new ScemaElement(Num, Ver, rnd.Next());
                    //tmp.Num = Num;
                    //tmp.Ver = Ver;
                    //tmp.Rand = new Random(rnd.Next());
                    ScElem.Add(tmp);
                    richTextBox1.Text += "Добавлен элемент " + tmp.Num + " с вероятностью " + tmp.Ver + "\n";
                    //todo
                    listView2.Items.Add(Num.ToString());
                }
                else//Иначе обновляем вероятность
                {
                    richTextBox1.Text += "Элементу с номером " + ScElem.Find(i => i.Num == Num).Num + " обновлена вероятность с " + ScElem.Find(i => i.Num == Num).Ver;
                    ScElem.Find(i => i.Num == Num).Ver = Ver;

                    richTextBox1.Text += " на " + ScElem.Find(i => i.Num == Num).Ver + "\n";
                }

                if (AllScema_Way.Count == 0 || ScElem.Count == 0)
                {
                    button1.Enabled = false;
                }
                else { button1.Enabled = true; }
                Update_Count_Button();
            }
            catch (Exception ex1)
            { //richTextBox1.Text += "Что-то пошло не по плану\nВероятно неправильный ввод числа с плавающей точкой\n"; 
                richTextBox1.Text += ex1.Message + "\n";
            }
        }


        //Добавить Путь из интерфейса
        //todo
        private void button5_Click(object sender, EventArgs e)
        {
            //Получение строки пути
            try
            {
                string Input_Str = textBox5.Text;

                for (int i = 0; i < Input_Str.Length; i++)
                {
                    //char tmpC = ;
                    if(char.IsDigit(Input_Str[i])||char.IsWhiteSpace(Input_Str[i]))
                    {

                    }
                    else
                    {
                        throw new Exception("В строке присутствуют не цифры");
                    }
                }

                /*if (textBox5.Text[textBox5.Text.Length-1]==' ')
                    textBox5.Text = textBox5.Text.Substring(0, textBox5.Text.Length-1);*/

                Save_Ways();
                Update_Count_Button();

                listBox2.Items.Add(Input_Str);
                richTextBox1.Text += "Добавлен путь "+Input_Str+"\n";

                
            }
            catch (Exception ex1) { //richTextBox1.Text += "Очень странно, что что-то не так";

                richTextBox1.Text += ex1.Message + "\n";
            
        }
            

        }


        //Счёт элементов из файла
        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                ScElem.Clear();
                listView2.Clear();
                //Опционально выбор
                string path = "";
                if (checkBox1.Checked)
                {
                    //openFileDialog1.ToString();
                    openFileDialog1.FileName = "";
                    openFileDialog1.ShowDialog();
                    if (openFileDialog1.FileName != "")
                        path = openFileDialog1.FileName;
                    else
                    {
                        //MessageBox.Show("Файл не был выбран");
                        richTextBox1.Text += "Файл для ввода элементов не был выбран\n";
                        return;
                    }
                }
                else
                { path = "Elem.txt"; richTextBox1.Text += "Применён путь для файлов по умолчанию\n"; }


                using (StreamReader sr = File.OpenText(path))
                {
                    string s1 = "";
                    string s2 = "";
                    s1 = sr.ReadLine();
                    do
                    {
                        s2 = sr.ReadLine();
                        ScemaElement tmp = new ScemaElement(Convert.ToInt32(s1), Convert.ToDouble(s2), rnd.Next());
                        //todo
                        listView2.Items.Add(s1);
                        //tmp.Num = Convert.ToInt32(s1);

                        //tmp.Ver = Convert.ToDouble(s2);
                        //tmp.Rand = new Random(rnd.Next());
                        ScElem.Add(tmp);
                        richTextBox1.Text += "Добавлен элемент " + tmp.Num + " с вероятностью " + tmp.Ver + "\n";

                        s1 = sr.ReadLine();
                    }
                    while (s1 != null);
                    richTextBox1.Text += "Загрузка элементов из файла завершена\n";

                    if (AllScema_Way.Count == 0 || ScElem.Count == 0)
                    {
                        button1.Enabled = false;
                    }
                    else { button1.Enabled = true; }
                }
                Update_Count_Button();
            }
            catch { 
                richTextBox1.Text += "Вероятно загрузочный файл не соответствует шаблону\nИзменения не были применены\n";
                ScElem.Clear();
                listView2.Clear();
            }
            

        }

        //Счёт путей из файла
        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                //AllScema_Way.Clear();
                listBox2.Items.Clear();
                string path = "";
                if (checkBox1.Checked)
                {
                    //openFileDialog1.ToString();
                    openFileDialog1.FileName = "";
                    openFileDialog1.ShowDialog();
                    if (openFileDialog1.FileName != "")
                        path = openFileDialog1.FileName;
                    else
                    {
                        //MessageBox.Show("Файл не был выбран");
                        richTextBox1.Text += "Файл для ввода путей не был выбран\n";
                        return;
                    }
                }
                else
                { path = "Way.txt"; richTextBox1.Text += "Применён путь для файлов по умолчанию\n"; }

                using (StreamReader sr = File.OpenText(path))
                {
                    string s = "";
                    s = sr.ReadLine();
                    do
                    {
                        /*string[] ScElem = s.Split(' ');

                        List<int> Way = new List<int>();

                        for (int i = 0; i < ScElem.Length; i++)
                        {

                            Way.Add(Convert.ToInt32(ScElem[i]));
                        }
                        //Добавить путь в схему путей
                        AllScema_Way.Add(Way);*/

                        //todo Отображение
                        listBox2.Items.Add(s);

                        s = sr.ReadLine();
                    }
                    while (s != null);
                    richTextBox1.Text += "Загрузка путей из файла завершена\n";
                }
                Save_Ways();
                Update_Count_Button();
            }
            catch
            {
                richTextBox1.Text += "Вероятно загрузочный файл не соответствует шаблону\nИзменения не были применены\n";
                listBox2.Items.Clear();
            }
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (AllScema_Way.Count != 0 && ScElem.Count != 0)
                {
                    int Count = Convert.ToInt32(textBox6.Text); //Число испытаний
                    if (Count < 1) { throw new Exception("Отрицательное число испытаний"); }

                    Scema_Way TMPscema_Way = new Scema_Way(AllScema_Way, ScElem);
                    //TMPscema_Way.Set_AllPath(AllScema_Way);
                    //TMPscema_Way.Set_ScElem(ScElem);
                    
                    label1.Text = TMPscema_Way.Count_Probability().ToString();
                    //label1.Text = "0,33333333333333333333333333333333333333333333333333333333333";
                    if (label1.Text.Length > 15)
                    label1.Text = label1.Text.Substring(0, 15);


                    label2.Text = TMPscema_Way.Count_Frequency(Count).ToString();
                    richTextBox1.Text += "Подсчёты выполнены успешно\n";
                }
                else
                {
                    richTextBox1.Text += "Подсчёты не были проведены\nОтсутствуют пути или элементы\n";
                }

            }

            catch (Exception eee) { richTextBox1.Text += "Что-то пошло не по плану\nВероятно некорректный ввод данных\n" + eee.Message + "\n"; }
            //catch ()
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try {
                /*AllScema_Way.Clear();
                foreach (var item in listBox2.Items)
                {
                    string[] ScWay = item.ToString().Split(' ');

                    List<int> Way = new List<int>();

                    for (int i = 0; i < ScWay.Length; i++)
                    {

                        Way.Add(Convert.ToInt32(ScWay[i]));
                    }
                    //Добавить путь в схему путей
                    AllScema_Way.Add(Way);

                    if (AllScema_Way.Count == 0 || ScElem.Count == 0)
                    {
                        button1.Enabled = false;
                    }
                    else { button1.Enabled = true; }
                }*/
            } catch {
                richTextBox1.Text += "Что-то пошло не по плану\nВероятно некорректные элементы пути или разделитель\n";
            }
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try {
                ScemaElement tmp = ScElem.Find(i => i.Num == Convert.ToInt32(listView2.SelectedItems[0].Text));
                //tmp.Add(ScElem.Find(i => i.Num == Convert.ToInt32(listView2.SelectedItems[0].ToString())));

                richTextBox1.Text += "Из списка удалён элемент " + tmp.Num + " с вероятностью " + tmp.Ver + "\n";
                ScElem.Remove(ScElem.Find(i => i.Num == Convert.ToInt32(listView2.SelectedItems[0].Text)));
                richTextBox1.Text += "Из просмотра удалён элемент " + listView2.SelectedItems[0].ToString() + "\n";

                //MessageBox.Show(listView2.SelectedItems[0].Text);
                //ScElem.Remove(tmp[0]);
                listView2.SelectedItems[0].Remove();
                if (AllScema_Way.Count == 0 || ScElem.Count == 0)
                {
                    button1.Enabled = false;
                }
                else { button1.Enabled = true; }
                Update_Count_Button();
            }
            catch { richTextBox1.Text += "Не удалось произвести удаление\nВероятно не был выбран элемент\n"; }
            

        }

        private void button9_Click(object sender, EventArgs e)
        {
            try {
                listBox2.Items.Remove(listBox2.SelectedItem);
                richTextBox1.Text += "Из просмотра удалены выбраные пути\n";
                if (AllScema_Way.Count == 0 || ScElem.Count == 0)
                {
                    button1.Enabled = false;
                }
                else { button1.Enabled = true; }
                Save_Ways();
                Update_Count_Button();
            }
            catch { }
        }

        private void richTextBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            richTextBox1.Clear();
        }

        
    }
}
