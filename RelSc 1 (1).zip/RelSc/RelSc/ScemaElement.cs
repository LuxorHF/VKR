﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RelSc
{
    //Класс для одного элемента схемы надёжности
    internal/*доступен по всей программе*/ class ScemaElement
    {
        public int Num;         //Номер события(название)
        public double Ver;      //Вероятность элемента, как события
        public Random Rand;

        public bool IsActive;   //Активен ли элемент схемы в данном испытании
        public ScemaElement(int Num, double Ver, int Rand) //Конструктор
        {

            if (Ver <= 1 && Ver >= 0)
            {
                this.Num = Num;
                this.Ver = Ver;
                this.Rand = new Random(Rand);
            }
            else throw new Exception("Не корректная вероятность");


        }
        public void Run_Element ()
        {
            if (Rand.NextDouble() <= Ver)
            {
                IsActive = true;
            }
            else { IsActive = false; }
        }
        //todo конструктор
        //todo get/set
        //todo - функция на срабатывание элемента
        //todo? - проверка на готовность элемента к работе - корректные вероятность и рандомайзер
    }

    //Возможно просто использовать лист листов int
    internal class Scema_Way
    {
        //public int Name;

        //todo конструктор
        //todo get/set


         List<List<int>> AllPath = new List<List<int>>();
         List<ScemaElement> ScElem = new List<ScemaElement>();

        double Veroyatnost = 0;
        double Chastota = 0;

        public Scema_Way(List<List<int>> AllPath, List<ScemaElement> ScElem)
        {
            bool a;
            bool may = true;

            //Добавить проверку Элементы -> Элементы пути
            //Добавить проверку Элементы пути -> Элементы 

            //Каждый из элементов хотя бы в одной строке
            foreach (var item in ScElem)
            {
                foreach (var item2 in AllPath)
                {
                    a = item2.Contains(item.Num);
                    if (a)
                    { may = false; break; }
                    may = true;
                }
                if (may)
                {
                    //Элемента нет ни в одной строке
                    throw new Exception("Элемента нет ни в одной строке");
                }
            }


            //В строке есть только элементы из списка
            foreach (var stroka in AllPath)
            {

                foreach (var elstroka in stroka)
                {
                    ScemaElement tmp = ScElem.Find(it => it.Num == elstroka);
                    if (tmp == null)
                    {
                        may = true;
                        throw  new Exception("Один из путей содержит необъявленные элементы " + elstroka.ToString());
                    };
                }

            }


            this.AllPath = AllPath;
            this.ScElem = ScElem;
        }

        
        public double Count_Probability()
        {
            //Составление таблицы истинности (на объявленных элементах схемы)
            List<List<int>> truthTable = new List<List<int>>();
            int n = ScElem.Count;// Количество переменных
            for (int i = 0; i < (1 << n); i++)
            {
                List<int> row = new List<int>();
                for (int j = 0; j < n; j++)
                {
                    if ((i & (1 << j)) != 0)
                    {
                        row.Add(1);
                    }
                    else
                    {
                        row.Add(0);
                    }
                }
                truthTable.Add(row);
            }

            //Построение совершенных конъюнктивных одночленов на основе объявленных путей
            List<List<int>> WaySKO = new List<List<int>>();
            foreach (var way in AllPath)
            {
                List<int> row = new List<int>();

                foreach (var item in ScElem)
                {

                    if (way.Exists(i => i == item.Num))
                    {
                        row.Add(1);
                    }
                    else
                    {
                        row.Add(0);
                    }

                }
                WaySKO.Add(row);
            }

            //Таблица апостериорной истинности (только СДНФ)
            List<List<int>> ApostTT = new List<List<int>>();
            foreach (var itemS in WaySKO)
            {
                for (int j = 0; j < truthTable.Count; j++)
                {
                    var itemT = truthTable[j];
                    bool fail = false;
                    for (int i = 0; i < ScElem.Count; i++)
                    {
                        if (itemS[i] == 1 && itemT[i] == 0)
                        {
                            fail = true;
                            break;
                        }
                        
                    }
                    if (!fail)
                    {
                        ApostTT.Add(itemT);
                        truthTable.Remove(itemT);
                        j--;
                    }
                }
            }

            //Подсчёт СДНФ
            double chway = 1;
            Veroyatnost = 0;
            foreach (var item in ApostTT)
            {
                for (int i = 0; i < ScElem.Count; i++)
                {
                    if (item[i] == 1)
                    {
                        chway *= ScElem[i].Ver;
                    }
                    else
                    {
                        chway *= (1 - ScElem[i].Ver);
                    }
                }

                Veroyatnost += chway;
                chway = 1;

            }

            return Veroyatnost;//Вывод
        }

        public double Get_Probability()
        {
            return Veroyatnost;
        }

        public double Count_Frequency(int Count)
        {
            int Count_SC = 0;
            bool Way_open = false;

            for (int i = 0; i < Count; i++)
            {
                ScElem.ForEach(item => item.Run_Element()); //Проверка на отказоустойчивость

                foreach (var way in AllPath)
                {
                    foreach (var elem in way)
                    {

                        ScemaElement tmp = ScElem.Find(it => it.Num == elem);

                        if (tmp.IsActive)
                        {
                            Way_open = true;
                        }
                        else
                        {
                            Way_open = false;
                            break;
                        }

                    }

                    if (Way_open)
                    {
                        Count_SC++;
                        Way_open = false;   //возможно излишне
                        break;
                    }

                }
            }
            Chastota = (double)Count_SC / (double)Count;
            return Chastota;
        }

        public double Get_Frequency()
        {
            return Chastota;
        }

        public void Set_AllPath(List<List<int>> AllPath)
        {
            this.AllPath = AllPath;
        }
        public void Set_ScElem(List<ScemaElement> ScElem)
        {
            this.ScElem = ScElem;
        }
    }
}
